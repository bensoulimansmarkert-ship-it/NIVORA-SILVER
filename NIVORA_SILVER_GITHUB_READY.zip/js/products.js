window.NIVORA_PRODUCTS=[
{id:"NV-001",title:"خاتم فضة 925 هلال",category:"rings",price:950,sourcePrice:863.64,source:"demo",description:"خاتم فضة بتصميم هادئ وفخم.",image:"",stock:8},
{id:"NV-002",title:"قلادة فضة 925 كلاسيكية",category:"necklaces",price:720,sourcePrice:654.55,source:"demo",description:"قلادة فضية بسيطة للاستخدام اليومي.",image:"",stock:12},
{id:"NV-003",title:"سوار فضة 925 ناعم",category:"bracelets",price:880,sourcePrice:800,source:"demo",description:"سوار فضة بتفاصيل دقيقة.",image:"",stock:6}
];