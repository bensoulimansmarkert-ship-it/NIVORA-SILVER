# Production API Integration Point

هذا المجلد يوضح مكان Backend الحقيقي.

لا تضع أي:
- AliExpress app secret
- access token
- database password
- payment gateway secret
داخل GitHub Pages.

Endpoints المقترحة:
POST /api/admin/login
GET /api/products
POST /api/products/import
POST /api/orders
POST /api/orders/:id/fulfill
GET /api/orders/:id/tracking
POST /api/payment/webhook
GET /api/accounting/summary

AliExpress/DSers:
- استقبال رابط المنتج أو product ID
- جلب title/images/variants/cost/shipping
- حساب سعر البيع وفق profit_percent
- حفظ sourceProductId وsupplierUrl
- إرسال الطلب للمورد
- استقبال tracking

قبل الإنتاج يجب اختبار الشحن إلى بلد العميل وتكلفة الشحن الفعلية وتوفر المقاس/اللون.
